/**
 * 文件介绍：
 * 该文件定义全局配置，方便后期维护
 */

//定义全局接口地址
var interfaceurl="https://www.baidu.com/";

//个人登录加密key
var GRKEY = "12345678";
var GRIV = "btdl";

//法人登录加密key
var FRKEY = "12345678";
var FRIV = "btdl";

//网站id
var btdlsiteid = 1;
//公共资源id
var publicclassifyid = 11;

//url1
var geturl1 = interfaceurl + "interface/geturl1.do";
//url2
var geturl2 = interfaceurl + "interface/geturl1.do";
//url3
var geturl3 = interfaceurl + "interface/geturl1.do";



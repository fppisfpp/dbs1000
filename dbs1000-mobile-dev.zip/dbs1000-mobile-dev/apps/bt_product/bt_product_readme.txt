项目介绍：

项目版本：

基于平台：bt_V1.0

目录介绍：
-> apps
     -> bt_product
                  -> BaseConfig.js
     -> baseconfig
     -> controller
     -> entity
     -> service
     -> source
                  -> css
                  -> fonts
                  -> images
     -> util
                  -> js
     -> view
     -> bt_product_readme.txt
var serverIp_config = localStorage.getItem('serverIp');  // 获取当前厂站的主机地址
var serverPort_config = localStorage.getItem('serverPort');  // 获取当前厂站的端口号
var applicationName_config = localStorage.getItem('applicationName'); // 获取当前应用的名称
// 接口地址的配置
var interface_config = {
	'selectUserName':'http://211.149.246.75:8080/Dbs2100/xtUserCloudserverController/getCustomerInfo', // 获取总控服务器的接口地址
	'login':"http://"+serverIp_config+':'+serverPort_config+'/'+applicationName_config+'/loginController/loginapp', // 登录接口地址
	'video':"http://"+serverIp_config+':'+serverPort_config+'/'+applicationName_config+'/videoController/index', // 视频获取接口
	'main' :'http://'+serverIp_config+':'+serverPort_config+'/'+applicationName_config+'/DefaultController/index', // 首页接口地址
	'report':'http://'+serverIp_config+':'+serverPort_config+'/'+applicationName_config+'/reportController/index', // 报告接口
	'serverinfo':'http://'+serverIp_config+':'+serverPort_config+'/'+applicationName_config+'serverInfoController/index', //服务信息接口
	
} ;

var LoginController = function($scope,$http) {
	$scope.userid = '' ; // 表示用户编号
	$scope.company_name = '' ;// 表示企业名称
	$scope.username = '' ; // 表示选中的用户名称
	$scope.account = '' ; // 表示登录的企业名称
	$scope.password = '' ; // 表示输入的密码
	$scope.userinfo = '' ;
	var userPicker = new mui.PopPicker();
	
	/**
	 * 需求:监听事件,当输入的字段值大于7的时候执行事件
	 * 作者:燕青
	 */
	$scope.$watch('userid',function(newdata,olddata){
		if(newdata.length == 7) {
			var customerNo = newdata ;
 			var url = interface_config['selectUserName']+"?customerNo="+customerNo;
 			$http.get(url, {}).then(function(data){
 				var object = eval('('+data.data+')');
 				if(object.userList != null && object.userList.length > 0){
	 				object.userList.forEach(function(index,value){
	   					object.userList[value]['text'] = index['userName'];
	   					object.userList[value]['value'] = index['userCode'];
	 				});
 				}
 				if(object.resp_code == 1) {
 					$scope.data = object.userList ;
 					localStorage.setItem('serverIp',object.serverIp);
 					localStorage.setItem('serverPort',object.serverPort);
 					localStorage.setItem('applicationName',object.applicationName);
 					$scope.company_name = object.customerName ;
 				}
 			}, function(){
 				console.info('error') ;
 			},'json');
		}
	});
	
	/**
	 * 需求:获取用户信息和云服务器信息
	 * 作者:燕青
	 */
	$scope.selectUserName = function() {
 		// 调用接口获取用户信息
		userPicker.setData($scope.data);
		var showUserPickerButton = document.getElementById('showUserPicker');
		var userResult = document.getElementById('userResult');
		showUserPickerButton.addEventListener('tap', function(event) {
			userPicker.show(function(items) {
				$scope.username = items[0].text;
				$scope.account = items[0].value;
				$scope.$apply(); // 脏数据检查
			});
		}, false);
	}
	/**
	 * 需求:登录操作
	 * 作者:燕青
	 */
	$scope.login = function(){
		// 调用登录接口
		var username = $scope.account ;
		var password = $scope.password ;
		var url = interface_config['login']+"?userName="+username+"&userPassword="+password+"&xt_userinfo_token=aisjklwekjlksajlksdjfl" ;
		console.info(url);
		$http.get(url, {}).then(function(data){
		   $scope.userinfo = data.data.xtUserinfo ;
		   if($scope.userinfo != null) {  // 动态写上
		   		// 获取厂站的信息
		   		localStorage.setItem('userinfo',$scope.userinfo);
				mui.toast('恭喜您,登录平台成功');
				window.location.href='../html/main.html' ;
			}else{
				mui.toast('对不起,用户名或者密码不正确');
			}
		}, function(){
			mui.toast('对不起,登录平台异常');
		},'json');
	}
}
angular.module('dbs',[]).controller('LoginController',LoginController);

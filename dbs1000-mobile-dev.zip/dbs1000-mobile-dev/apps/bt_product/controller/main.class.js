var MainController = function($scope,$http){
	$scope.picture = '../images/main/banner.png' ; // 表示首页图片
	$scope.baseinfo = '测试基础平台信息' ; // 平台信息
	$scope.blightinfo = '测试基础警告信息' ; // 告警信息
	$scope.news = [] ; // 新闻列表
	var url = "http://localhost:8080/jehc/defaultController/index?stationid=62BF40B65A9149CEBE9EC6301BC2D21F";
	$http.get(url, {}).then(function(data){
		if(data.data != null) {
			$scope.picture = (data.data.aPpindex != null) ? data.data.aPpindex.jehcimg_base_path_url :'';
			$scope.baseinfo = (data.data.aPpindex != null) ? data.data.aPpindex.baseinfo :'' ;
			$scope.blightinfo = (data.data.aPpindex != null) ? data.data.aPpindex.blightinfo : '';
			$scope.news = (data.data.aPpindex != null) ? data.data.aPpindex.f_news:[];
		}
	}, function(){
		console.info('error') ;
	},'json');
}
angular.module('dbs',[]).controller('MainController',MainController);
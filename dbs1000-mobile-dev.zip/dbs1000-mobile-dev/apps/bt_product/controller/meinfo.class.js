var MeInfoController = function($scope,$http) {
	var url = interface_config['login']+"?userName=250000&userPassword=123456&xt_userinfo_token=aisjklwekjlksajlksdjfl" ;
	$http.get(url, {}).then(function(data){
	   $scope.userinfo = data.data.xtUserinfo ;
	   console.info($scope.userinfo);
	}, function(){
	},'json');
	
	$scope.logout = function() {
		localStorage.setItem('userinfo',null);
		window.location.href = 'login.html';
	}
}
angular.module('dbs',[]).controller('MeInfoController',MeInfoController);
var RealTimeController = function($scope,$http) {
	var userPicker = new mui.PopPicker();
	$scope.selectStation = function(btn){
		// 调用接口获取用户信息
		userPicker.setData([
			{value:'1000',text:'展览中心'},
			{value:'1001',text:'软件公寓'},
		]);
		var showUserPickerButton = document.getElementById('f_stations');
		var userResult = document.getElementById('f_stations_result');
		showUserPickerButton.addEventListener('tap', function(event) {
			userPicker.show(function(items) {
				showUserPickerButton.value = items[0].text;
				$scope.account = items[0].value;
			});
		}, false);
	}
	
	
}
angular.module('dbs',[]).controller('RealTimeController',RealTimeController);
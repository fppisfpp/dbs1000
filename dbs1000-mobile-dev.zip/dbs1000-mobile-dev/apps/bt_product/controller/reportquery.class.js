var ReportQueryController = function($scope,$http){
	$scope.stationid = '' ;
	$scope.start_time = '' ;
	$scope.end_time = '' ;
	var userPicker = new mui.PopPicker();
	/**
	 * 需求:时间插件 
	 * @param {Object} btn
	 */
	$scope.selectTime = function(btn){
		btn.target.addEventListener('tap', function() {
			var _self = this;
			if(_self.picker) {
				_self.picker.show(function (rs) {
					btn.target.value=rs.text;
				});
			} else {
				var optionsJson = this.getAttribute('data-options') || '{}';
				var options = JSON.parse(optionsJson);
				var id = this.getAttribute('id');
				_self.picker = new mui.DtPicker(options);
				_self.picker.show(function(rs) {
					if(btn.target.id == 'start_time') {
						$scope.start_time = rs.value;
					}else if(btn.target.id == 'end_time') {
						$scope.end_time = rs.value; ;
					}
					btn.target.value=rs.text;
					$scope.$apply();
					
				});
			}
		}, false);
	}
	
	$scope.selectStation = function(btn){
		// 调用接口获取用户信息
		userPicker.setData([
			{value:'EAEABB6663544900961DD9058C0B347E',text:'展览中心'},
			{value:'62BF40B65A9149CEBE9EC6301BC2D21F',text:'软件公寓'},
		]);
		var showUserPickerButton = document.getElementById('f_stations');
		var userResult = document.getElementById('f_stations_result');
		showUserPickerButton.addEventListener('tap', function(event) {
			userPicker.show(function(items) {
				showUserPickerButton.value = items[0].text;
				$scope.stationid = items[0].value;
				$scope.$apply();
			});
		}, false);
	}
}

angular.module('dbs',[]).controller('ReportQueryController',ReportQueryController);

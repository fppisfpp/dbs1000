var ServerInfoController = function($scope,$http){
	$scope.f_workingday = '10';
	$scope.f_serverpeople = '杨健001';
	$scope.f_servertel = '13813899654';
	$scope.f_serverday = '20';
	$scope.f_inspectioncount = '40';
	$scope.f_cleancount = '3';
	$scope.f_repaircount = '5' ;
	$scope.f_operatecount = '20';
}

angular.module('dbs',[]).controller('ServerInfoController',ServerInfoController);
/**
 * 需求:视频控制器
 * 作者:燕青
 */
var VideoController = function($scope,$http) {
	$scope.video = [] ;
	var url = interface_config['video']+"?stationid="+"62BF40B65A9149CEBE9EC6301BC2D21F";
	//var url = "http://localhost:8080/jehc/videoController/index?stationid=62BF40B65A9149CEBE9EC6301BC2D21F";
	$http.get(url, {}).then(function(data){
		$scope.video = data.data.vodeoList ;
	}, function(){
		
	},'json');
}
angular.module('dbs',[]).controller('VideoController',VideoController);
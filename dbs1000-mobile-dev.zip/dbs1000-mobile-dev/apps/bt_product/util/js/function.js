//网络状态
function onNetworkType() {
    networkType({
        success:function(data){
            alert(data);
        },
        fail:function(data){
            alert(data);
        }
    });
};

